package softuni.exam.models.dto.mechanic;

public class ImportMechanicsDTO {
}
