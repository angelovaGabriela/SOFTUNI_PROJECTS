package softuni.exam.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface MechanicRepository {


}
