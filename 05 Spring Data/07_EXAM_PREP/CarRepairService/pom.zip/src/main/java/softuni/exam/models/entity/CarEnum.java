package softuni.exam.models.entity;

public enum CarEnum {
    SUV, coupe, sport
}
