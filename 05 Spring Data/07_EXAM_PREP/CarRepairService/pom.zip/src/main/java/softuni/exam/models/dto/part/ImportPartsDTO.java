package softuni.exam.models.dto.part;

public class ImportPartsDTO {
}
