package softuni.exam.models.dto.task;


public class ImportTasksDTO {
}
