package com.likebookapp.service;

public interface MoodService {
    void initMood();
}
