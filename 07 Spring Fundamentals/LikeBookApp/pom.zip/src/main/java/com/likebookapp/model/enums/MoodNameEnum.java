package com.likebookapp.model.enums;

public enum MoodNameEnum {
    Happy, Sad, Inspired
}
