package com.bonappetit.service;

public interface HomeService {
    void addToFavourites(Long recipeId, Long id);
}
