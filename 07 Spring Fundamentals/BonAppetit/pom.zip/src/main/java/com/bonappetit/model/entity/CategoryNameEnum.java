package com.bonappetit.model.entity;

public enum CategoryNameEnum {
    MAIN_DISH, DESSERT, COCKTAIL;
}
